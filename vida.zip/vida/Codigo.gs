/**
 * vida — backend Apps Script para a "Planilha do App Vida"
 * --------------------------------------------------------
 * Conecta o HTML (index.html) à planilha.
 *
 * As colunas são localizadas pelo NOME do cabeçalho (linha 4), então o
 * script funciona mesmo que a ordem mude e tolera a aba antiga.
 * Registros começam na linha 5.
 *
 * Cabeçalhos reconhecidos (linha 4), com ou sem emoji/acento:
 *   Data | Exercício | Dieta: Café | Dieta: Almoço | Dieta: Lanche |
 *   Dieta: Jantar | Água | Estudo | Sono
 *
 * Água  -> número de mL (0 a 6000).
 * Sono  -> número de horas (0 a 24).
 * Valores antigos em texto são convertidos para um número aproximado.
 */

var HEADER_ROW = 4;
var FIRST_ROW  = 5;

function fieldForHeader_(h){
  var s = stripEmoji_(String(h||"")).toLowerCase().replace(/\s+/g," ").trim();
  s = s.replace(/[áàâã]/g,"a").replace(/[éê]/g,"e").replace(/í/g,"i").replace(/[óô]/g,"o").replace(/ú/g,"u").replace(/ç/g,"c");
  if(s==="data") return "data";
  if(s.indexOf("exercic")===0) return "exercicio";
  if(s.indexOf("cafe")>=0)   return "cafe";
  if(s.indexOf("almoco")>=0) return "almoco";
  if(s.indexOf("lanche")>=0) return "lanche";
  if(s.indexOf("jantar")>=0) return "jantar";
  if(s.indexOf("agua")>=0)   return "agua";
  if(s.indexOf("estudo")>=0) return "estudo";
  if(s.indexOf("sono")>=0)   return "sono";
  return null;
}

function sheetFor_(person){
  if(!person) return null;
  var p = stripEmoji_(String(person)).toLowerCase();
  if(p.indexOf("hen")===0) return "Henrique";
  if(p.indexOf("j")===0)   return "Júlia";
  return null;
}
function ss_(){ return SpreadsheetApp.getActiveSpreadsheet(); }

function stripEmoji_(v){
  return String(v).replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{1F1E6}-\u{1F1FF}\u{1F3FB}-\u{1F3FF}\uFE0F\u200D]/gu,"").trim();
}

function colMap_(sh){
  var lastCol = sh.getLastColumn();
  var heads = sh.getRange(HEADER_ROW, 1, 1, lastCol).getValues()[0];
  var map = {};
  for(var c=0;c<heads.length;c++){
    var f = fieldForHeader_(heads[c]);
    if(f && !map[f]) map[f] = c+1;
  }
  return map;
}

function toISO_(v){
  if(v instanceof Date) return Utilities.formatDate(v, ss_().getSpreadsheetTimeZone(), "yyyy-MM-dd");
  return String(v||"").trim();
}
function clean_(v){ return stripEmoji_(v); }

function sonoToNumber_(v){
  if(v === "" || v == null) return "";
  if(typeof v === "number") return v;
  var s = stripEmoji_(String(v)).toLowerCase();
  if(!s) return "";
  if(s.indexOf("< 7")>=0 || s.indexOf("<7")>=0 || s.indexOf("menos")>=0) return 6;
  if(s.indexOf("> 9")>=0 || s.indexOf(">9")>=0 || s.indexOf("mais")>=0)  return 9.5;
  if(s.indexOf("8h59")>=0 || s.indexOf("7h")>=0) return 8;
  var n = parseFloat(s.replace(",","."));
  return isNaN(n) ? "" : n;
}
function waterToNumber_(v){
  if(v === "" || v == null) return "";
  if(typeof v === "number") return v;
  var s = stripEmoji_(String(v)).toLowerCase();
  if(!s) return "";
  if(s.indexOf("insufic")>=0) return 1000;   // legado aproximado
  if(s.indexOf("sufic")>=0)   return 2500;   // legado aproximado
  var n = parseFloat(s.replace(/[^0-9.,]/g,"").replace(",","."));
  return isNaN(n) ? "" : n;
}

/* ---------------- LEITURA (GET) ---------------- */
function doGet(e){
  var person = e && e.parameter ? e.parameter.person : null;
  var name = sheetFor_(person);
  if(name) return json_({ person:person, records: readRecords_(name) });
  return json_({ Henrique: readRecords_("Henrique"), "Júlia": readRecords_("Júlia") });
}

function readRecords_(sheetName){
  var sh = ss_().getSheetByName(sheetName);
  if(!sh) return [];
  var last = sh.getLastRow();
  if(last < FIRST_ROW) return [];
  var map = colMap_(sh);
  if(!map.data) return [];
  var lastCol = sh.getLastColumn();
  var rows = sh.getRange(FIRST_ROW, 1, last - FIRST_ROW + 1, lastCol).getValues();
  function val(row, field){ return map[field] ? row[map[field]-1] : ""; }
  var recs = [];
  for(var i=0;i<rows.length;i++){
    var r = rows[i];
    if(!r[map.data-1]) continue;
    recs.push({
      data:      toISO_(r[map.data-1]),
      exercicio: clean_(val(r,"exercicio")),
      cafe:      clean_(val(r,"cafe")),
      almoco:    clean_(val(r,"almoco")),
      lanche:    clean_(val(r,"lanche")),
      jantar:    clean_(val(r,"jantar")),
      agua:      waterToNumber_(val(r,"agua")),
      estudo:    clean_(val(r,"estudo")),
      sono:      sonoToNumber_(val(r,"sono"))
    });
  }
  return recs;
}

/* ---------------- ESCRITA (POST) ---------------- */
function doPost(e){
  var lock = LockService.getScriptLock();
  lock.tryLock(15000);
  try{
    var body = JSON.parse(e.postData.contents);
    var name = sheetFor_(body.person);
    var rec  = body.record || {};
    if(!name)     return json_({ ok:false, error:"pessoa inválida" });
    if(!rec.data) return json_({ ok:false, error:"data ausente" });
    var sh = ss_().getSheetByName(name);
    if(!sh)       return json_({ ok:false, error:"aba não encontrada: "+name });

    var map = colMap_(sh);
    if(!map.data) return json_({ ok:false, error:"cabeçalho 'Data' não encontrado na linha "+HEADER_ROW });

    var rowIdx = findRowByDate_(sh, map.data, rec.data);
    var isNew = false;
    if(rowIdx === -1){ rowIdx = Math.max(sh.getLastRow()+1, FIRST_ROW); isNew = true; sh.getRange(rowIdx, map.data).setValue(toDate_(rec.data)); }

    var fields = ["exercicio","cafe","almoco","lanche","jantar","agua","estudo","sono"];
    var numeric = { agua:true, sono:true };
    var ignored = [];
    for(var i=0;i<fields.length;i++){
      var f = fields[i], v = rec[f];
      if(v === undefined || v === null || v === "") continue;
      if(!map[f]){ ignored.push(f); continue; }
      sh.getRange(rowIdx, map[f]).setValue(numeric[f] ? Number(v) : v);
    }
    return json_({ ok:true, row:rowIdx, new:isNew, ignored:ignored });
  }catch(err){
    return json_({ ok:false, error:String(err) });
  }finally{
    lock.releaseLock();
  }
}

function findRowByDate_(sh, dataCol, iso){
  var last = sh.getLastRow();
  if(last < FIRST_ROW) return -1;
  var dates = sh.getRange(FIRST_ROW, dataCol, last - FIRST_ROW + 1, 1).getValues();
  for(var i=0;i<dates.length;i++){ if(dates[i][0] && toISO_(dates[i][0]) === iso) return FIRST_ROW + i; }
  return -1;
}
function toDate_(iso){ var p=iso.split("-"); return new Date(Number(p[0]), Number(p[1])-1, Number(p[2])); }
function json_(obj){ return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }

/* ============================================================
   INSTALAÇÃO
   1. Planilha > Extensões > Apps Script. Cole este arquivo e salve.
   2. Implantar > Nova implantação > App da Web
        Executar como: Eu | Acesso: Qualquer pessoa. Copie a URL "/exec".
   3. Em index.html, 1ª linha do <script>:
        const CONFIG = { API_URL: "COLE_AQUI_/exec" };

   FORMATO DAS ABAS (deixe as duas iguais, linha 4):
     B: Data | C: Exercício | D: Dieta: Café | E: Dieta: Almoço |
     F: Dieta: Lanche | G: Dieta: Jantar | H: Água | I: Estudo | J: Sono
   - Água e Sono devem ser colunas livres (número), sem validação de lista.
   - Nomes das abas: "Henrique" e "Júlia".
   ============================================================ */
